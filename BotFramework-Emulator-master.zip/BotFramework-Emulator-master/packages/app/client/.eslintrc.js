module.exports = {
  extends: '../../../.eslintrc.react.js',
};
