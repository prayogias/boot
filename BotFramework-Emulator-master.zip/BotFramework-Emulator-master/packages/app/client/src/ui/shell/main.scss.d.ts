// This is a generated file. Changes are likely to result in being overwritten
export const main: string;
export const nav: string;
export const workbench: string;
export const mdiWrapper: string;
export const secondaryMdi: string;
