// This is a generated file. Changes are likely to result in being overwritten
export const explorerBarHeader: string;
export const accessory: string;
export const botSettings: string;
export const explorerSet: string;
