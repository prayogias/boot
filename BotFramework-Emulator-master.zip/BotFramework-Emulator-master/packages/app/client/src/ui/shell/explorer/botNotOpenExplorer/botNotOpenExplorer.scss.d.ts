// This is a generated file. Changes are likely to result in being overwritten
export const botNotOpenExplorer: string;
export const explorerEmptyState: string;
export const openBot: string;
