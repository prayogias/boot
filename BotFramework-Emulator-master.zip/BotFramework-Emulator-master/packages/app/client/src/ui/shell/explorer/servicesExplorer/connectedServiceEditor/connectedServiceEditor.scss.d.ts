// This is a generated file. Changes are likely to result in being overwritten
export const connectedServiceEditor: string;
export const header: string;
export const kvPairContainer: string;
export const noBorder: string;
