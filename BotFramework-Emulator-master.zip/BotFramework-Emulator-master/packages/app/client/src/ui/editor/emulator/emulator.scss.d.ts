// This is a generated file. Changes are likely to result in being overwritten
export const emulator: string;
export const vertical: string;
export const header: string;
export const toolbarIcon: string;
export const restartIcon: string;
export const saveIcon: string;
export const content: string;
export const presentation: string;
export const chatPanel: string;
export const presentationContent: string;
export const closePresentationIcon: string;
export const presentationPlaybackDock: string;
