// This is a generated file. Changes are likely to result in being overwritten
export const marginFix: string;
export const noBots: string;
export const recentBot: string;
export const recentBotPath: string;
export const recentBotActionBar: string;
export const recentBotsList: string;
export const section: string;
export const well: string;
