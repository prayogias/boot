// This is a generated file. Changes are likely to result in being overwritten
export const webViewContainer: string;
export const detailPanel: string;
export const accessoryButton: string;
export const accessoryButtonIcon: string;
export const inspectorContainer: string;
export const nothingInspected: string;
export const leftArrow: string;
export const leftArrowSelected: string;
export const rightArrow: string;
export const rightArrowSelected: string;
