// This is a generated file. Changes are likely to result in being overwritten
export const chat: string;
export const chatActivity: string;
export const selectedActivity: string;
export const disconnected: string;
export const startButton: string;
export const botStateObject: string;
