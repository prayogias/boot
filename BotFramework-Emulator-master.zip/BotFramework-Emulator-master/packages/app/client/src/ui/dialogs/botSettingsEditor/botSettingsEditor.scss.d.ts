// This is a generated file. Changes are likely to result in being overwritten
export const botSettingsEditor: string;
export const cancelButton: string;
export const saveButton: string;
export const key: string;
export const encryptKeyCheckBox: string;
export const actionsList: string;
export const disabledAction: string;
