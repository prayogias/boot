// This is a generated file. Changes are likely to result in being overwritten
export const host: string;
export const dialogHostVisible: string;
export const dialogHostContent: string;
export const focusSentinel: string;
