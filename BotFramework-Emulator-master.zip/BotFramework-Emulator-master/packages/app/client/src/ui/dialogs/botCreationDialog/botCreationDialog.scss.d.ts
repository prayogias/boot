// This is a generated file. Changes are likely to result in being overwritten
export const main: string;
export const multiInputRow: string;
export const inputContainer: string;
export const botCreateForm: string;
export const endpointWarning: string;
export const key: string;
export const encryptKeyCheckBox: string;
export const actionsList: string;
export const disabledAction: string;
