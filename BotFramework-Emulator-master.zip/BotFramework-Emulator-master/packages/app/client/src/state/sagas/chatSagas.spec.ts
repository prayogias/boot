//
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license.
//
// Microsoft Bot Framework: http://botframework.com
//
// Bot Framework Emulator Github:
// https://github.com/Microsoft/BotFramwork-Emulator
//
// Copyright (c) Microsoft Corporation
// All rights reserved.
//
// MIT License:
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
import { applyMiddleware, combineReducers, createStore } from 'redux';
import sagaMiddlewareFactory from 'redux-saga';
import { ActivityTypes } from 'botframework-schema';
import * as Electron from 'electron';
import { SharedConstants, ValueTypes } from '@bfemulator/app-shared';
import { CommandServiceImpl, CommandServiceInstance, ConversationService } from '@bfemulator/sdk-shared';

import { bot } from '../reducers/bot';
import { chat } from '../reducers/chat';
import { editor } from '../reducers/editor';
import { presentation } from '../reducers/presentation';
import * as Constants from '../../constants';
import { closeConversation, newChat, showContextMenuForActivity } from '../actions/chatActions';
import { closeBot } from '../actions/botActions';
import { clientAwareSettings } from '../reducers/clientAwareSettings';

import { chatSagas } from './chatSagas';

const sagaMiddleWare = sagaMiddlewareFactory();
let mockStore;
let mockStoreState;
jest.mock('../../ui/dialogs', () => ({}));
jest.mock('../store', () => ({
  get store() {
    return mockStore;
  },
}));

jest.mock('electron', () => {
  return {
    ipcMain: new Proxy(
      {},
      {
        get(): any {
          return () => ({});
        },
        has() {
          return true;
        },
      }
    ),
    ipcRenderer: new Proxy(
      {},
      {
        get(): any {
          return () => ({});
        },
        has() {
          return true;
        },
      }
    ),
    clipboard: { writeText: (textFromActivity: string) => true },
  };
});

jest.mock('botframework-webchat', () => {
  return {
    createCognitiveServicesBingSpeechPonyfillFactory: () => () => 'Yay! ponyfill!',
  };
});

const log = {
  entries: [
    {
      items: [
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a075a350-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:41-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:41.957Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'fullname',
                          values: {},
                        },
                      },
                      {
                        id: 'fullname',
                        state: {
                          slot: 'first',
                          values: {},
                        },
                      },
                      {
                        id: 'text',
                        state: {
                          options: {
                            prompt: 'Please enter your first name.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '2',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
            text: 'trace',
          },
          type: 'inspectable-object',
        },
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a075a350-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:41-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:41.957Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'fullname',
                          values: {},
                        },
                      },
                      {
                        id: 'fullname',
                        state: {
                          slot: 'first',
                          values: {},
                        },
                      },
                      {
                        id: 'text',
                        state: {
                          options: {
                            prompt: 'Please enter your first name.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '2',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
          },
          type: 'summary-text',
        },
      ],
      timestamp: 1554407741957,
    },
    {
      items: [
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a498c020-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:48-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:48.898Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'fullname',
                          values: {},
                        },
                      },
                      {
                        id: 'fullname',
                        state: {
                          slot: 'last',
                          values: {
                            first: 'Justin ',
                          },
                        },
                      },
                      {
                        id: 'text',
                        state: {
                          options: {
                            prompt: 'Please enter your last name.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '3',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
            text: 'trace',
          },
          type: 'inspectable-object',
        },
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a498c020-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:48-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:48.898Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'fullname',
                          values: {},
                        },
                      },
                      {
                        id: 'fullname',
                        state: {
                          slot: 'last',
                          values: {
                            first: 'Justin ',
                          },
                        },
                      },
                      {
                        id: 'text',
                        state: {
                          options: {
                            prompt: 'Please enter your last name.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '3',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
          },
          type: 'summary-text',
        },
      ],
      timestamp: 1554407748898,
    },
    {
      items: [
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a65d2c70-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:51-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:51.863Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'age',
                          values: {
                            fullname: {
                              slot: 'last',
                              values: {
                                first: 'Justin ',
                                last: 'Wilaby',
                              },
                            },
                          },
                        },
                      },
                      {
                        id: 'number',
                        state: {
                          options: {
                            prompt: 'Please enter your age.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '4',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
            text: 'trace',
          },
          type: 'inspectable-object',
        },
        {
          payload: {
            obj: {
              channelId: 'emulator',
              conversation: {
                conversationType: 'personal',
                id: '9fb93120-5713-11e9-a20f-e185020ba18b|livechat',
              },
              from: {
                aadObjectId: '8d81b1c4-a057-4d27-a41d-e40b3105e6ee',
                id: '29:1roELw8-HUdxuNSlGwtGqacHW_y-tsmLhvs42duabIDv0JFovw3WX7QC-syrrAYRt0RHBqoS1i0Mt18un1YZmyw',
                name: 'Justin Wilaby',
                role: 'user',
              },
              id: 'a65d2c70-5713-11e9-a20f-e185020ba18b',
              label: 'Bot State',
              localTimestamp: '2019-04-04T12:55:51-07:00',
              locale: 'en',
              name: 'BotState',
              recipient: {
                id: '28:825059e1-0dd5-4a90-9136-121a702c18ca',
                role: 'user',
              },
              serviceUrl: 'http://localhost:9000',
              timestamp: '2019-04-04T19:55:51.863Z',
              type: 'trace',
              value: {
                conversationState: {
                  dialogState: {
                    conversationState: {},
                    dialogStack: [
                      {
                        id: 'root',
                        state: {
                          options: {},
                          stepIndex: 0,
                          values: {
                            instanceId: '6938f312-523a-2db2-92ba-9680f559dd2d',
                          },
                        },
                      },
                      {
                        id: 'slot-dialog',
                        state: {
                          slot: 'age',
                          values: {
                            fullname: {
                              slot: 'last',
                              values: {
                                first: 'Justin ',
                                last: 'Wilaby',
                              },
                            },
                          },
                        },
                      },
                      {
                        id: 'number',
                        state: {
                          options: {
                            prompt: 'Please enter your age.',
                          },
                          state: {},
                        },
                      },
                    ],
                    userState: {},
                  },
                  eTag: '4',
                },
                userState: {},
              },
              valueType: 'https://www.botframework.com/schemas/botState',
            },
          },
          type: 'summary-text',
        },
      ],
      timestamp: 1554407751863,
    },
  ],
};

describe('The ChatSagas,', () => {
  beforeEach(() => {
    mockStoreState = {
      bot: {
        activeBot: {
          services: [{ id: 'endpoint2', appId: 'anAppId', appPassword: 'anAppPassword' }],
        },
      },
      chat: {
        chats: {
          doc1: {
            log,
            conversationId: 'convo1',
            documentId: 'doc1',
            endpointId: 'endpoint1',
            userId: 'someUserId',
          },
        },
      },
      editor: {
        activeEditor: Constants.EDITOR_KEY_PRIMARY,
        editors: {
          [Constants.EDITOR_KEY_PRIMARY]: {
            activeDocumentId: 'doc1',
          },
        },
      },
      presentation: { enabled: true },
      clientAwareSettings: { serverUrl: 'localhost:3000' },
    };

    mockStore = createStore(
      combineReducers({
        bot,
        chat,
        editor,
        presentation,
        clientAwareSettings,
      }),
      mockStoreState,
      applyMiddleware(sagaMiddleWare)
    );
    sagaMiddleWare.run(chatSagas);
  });

  describe('when showing a context menu for an activity', () => {
    let commandService: CommandServiceImpl;
    beforeAll(() => {
      const decorator = CommandServiceInstance();
      const descriptor = decorator({ descriptor: {} }, 'none') as any;
      commandService = descriptor.descriptor.get();
    });
    it('should handle the "copy message" selection', async () => {
      const commandServiceSpy = jest.spyOn(commandService, 'remoteCall').mockResolvedValue({ id: 'copy' });
      const clipboardSpy = jest.spyOn(Electron.clipboard, 'writeText');
      const activity = {
        valueType: ValueTypes.Activity,
        type: ActivityTypes.Trace,
        value: { type: ActivityTypes.Message, text: 'Hello Bot!' },
      };
      mockStore.dispatch(showContextMenuForActivity(activity));
      await Promise.resolve(true);
      expect(commandServiceSpy).toHaveBeenCalled();
      expect(clipboardSpy).toHaveBeenCalledWith('Hello Bot!');
    });

    it('should handle the "copy json" selection', async () => {
      const commandServiceSpy = jest.spyOn(commandService, 'remoteCall').mockResolvedValue({ id: 'json' });
      const clipboardSpy = jest.spyOn(Electron.clipboard, 'writeText');
      const activity = {
        valueType: '',
        type: ActivityTypes.Trace,
        value: { type: ActivityTypes.Message, text: 'Hello Bot!' },
      };
      await mockStore.dispatch(showContextMenuForActivity(activity));
      await Promise.resolve(true);
      expect(commandServiceSpy).toHaveBeenCalled();
      expect(clipboardSpy).toHaveBeenCalledWith(JSON.stringify(activity, null, 2));
    });

    it('when closing a document it should notify the main process so it can remove the conversation', async () => {
      const commandServiceSpy = jest.spyOn(commandService, 'remoteCall').mockResolvedValue(true);
      mockStore.dispatch(closeConversation('doc1'));
      expect(commandServiceSpy).toHaveBeenCalledWith(SharedConstants.Commands.Emulator.DeleteConversation, 'convo1');
      await Promise.resolve(); // wait for the comand service call to complete
      expect(mockStore.getState().chat.chats.doc1).toBeUndefined();
    });

    it('when starting a new conversation, should create a speech token ponyfill factory', async () => {
      const commandServiceSpy = jest.spyOn(commandService, 'remoteCall').mockResolvedValue('mockSpeechToken');

      mockStore.dispatch(
        newChat('doc2', 'livechat', {
          conversationId: 'convo2',
          endpointId: 'endpoint2',
          userId: 'someUserId2',
        })
      );

      await Promise.resolve();
      const state = mockStore.getState();
      expect(state.chat.chats.doc2).not.toBeUndefined();
      expect(state.chat.webSpeechFactories.doc2).not.toBeUndefined();
      expect(state.chat.webSpeechFactories.doc2()).toBe('Yay! ponyfill!');
      expect(commandServiceSpy).toHaveBeenCalledWith(
        SharedConstants.Commands.Emulator.GetSpeechToken,
        'endpoint2',
        false
      );
    });

    it('should try to retrieve the bot from the service when no active bot file is in play', async () => {
      const mockEndpointResponse = { ok: true, json: async () => ({ appId: 'appId', appPassword: 'appPassword' }) };
      const spy = jest
        .spyOn(ConversationService, 'getConversationEndpoint')
        .mockResolvedValueOnce(mockEndpointResponse as any);

      mockStore.dispatch(closeBot());
      mockStore.dispatch(
        newChat('doc2', 'livechat', {
          conversationId: 'convo2',
          endpointId: 'endpoint2',
          userId: 'someUserId2',
        })
      );
      expect(spy).toHaveBeenCalled();
    });
  });
});
